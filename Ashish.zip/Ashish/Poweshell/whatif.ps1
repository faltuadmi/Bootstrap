﻿Copy-Item "E:\ps\WhatifTesting\dora.png" -Destination "E:\ps\WhatifTesting\Destination"  -WhatIf

Stop-Service BITS -WhatIf

Start-Service BITS -WhatIf


Remove-Item 'C:\MyDB' -Recurse -WhatIf


Get-ChildItem -File '*.mdf' -Recurse -LiteralPath C:\MyDB\ | Remove-Item -WhatIf


get-help WhatIf

